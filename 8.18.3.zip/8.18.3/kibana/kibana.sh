#!/bin/bash
set -e

# Files created at run-time should be group-writable
umask 0002

function prepend-with-date {
  while read line
  do
    echo $(date +%Y-%m-%dT%H:%M:%S%z) $line
  done
}

{% set cluster_data = jsonMap(container.clusterData()) %}
{% set instance_data = jsonMap(container.instanceData()) %}

# Since 7.7.0 we've switched to use upstream images which have different file location
if [ -d /usr/share/kibana ]; then
    KIBANA_HOME=/usr/share/kibana
else
    KIBANA_HOME=/kibana
fi

if [[ $(id -u) -eq 0 ]]; then
    echo "ERROR: kibana.sh running as uid 0 (root), exiting."
    exit 1
fi

cd /app

mkdir -p logs
BOOT_LOG_FILE=logs/boot.log
# save stdout and stderr for later
exec 3>&1 4>&2
exec >  >(prepend-with-date | tee -a $BOOT_LOG_FILE)
exec 2> >(prepend-with-date | tee -a $BOOT_LOG_FILE >&2)

echo "Booting at $(date)"

echo "Done preparing, starting Kibana. See Kibana logs for further output."

# used by the request-filter in kibana
export CLUSTER_NAME={{ container.id().group() }}
# used by the cloud headers patch in kibana
export ELASTICSEARCH_CLUSTER_NAME={{ cluster_data.elasticsearch_cluster_id }}

# used by metricbeat
export ECE_COMPONENT="kibana"
export ECE_CLUSTER_NAME="{{ container.id().group() }}"
export ECE_INSTANCE_ID="{{ container.id().name() }}"
export ECE_CLUSTER_VERSION="{{ container.versionString() }}"

export CLOUD_KIBANA_CAPACITY={{ instance_data.instance_capacity }}

# restore stdout and stderr
exec 1>&3 2>&4

# TODO: add a marker for found-es-monitor to find? e.g -Dfound.kibana_cluster_name={{ container.id().group() }} -Dfound.kibana_instance_name={{ container.id().name() }}

{# 800MB of max_old_space_size per GB of Kibana container size, subject to a min of 800MB #}
{% set max_old_space_size = (instance_data.instance_capacity|default(1024) / 1024 * 800) | int %}
{% if max_old_space_size < 800 %}
  {% set max_old_space_size = 800 %}
{% endif %}


run_beat () {
  BEAT_NAME=${1}
  # Remove any lockfile left over from a container restart
  rm -f /tmp/${BEAT_NAME}-data/${BEAT_NAME}.lock || true
  while true; do
    /opt/${BEAT_NAME}/${BEAT_NAME} --path.config /app/config/${BEAT_NAME} --path.data /tmp/${BEAT_NAME}-data
    echo "${BEAT_NAME} exited with code $?. Re-running in 2 seconds"
    sleep 2
  done
}

{% if instance_data.observability.logging is defined %}
echo "Starting filebeat"
run_beat filebeat &
{% endif %}
{% if instance_data.observability.metrics is defined %}
echo "Starting metricbeat"
run_beat metricbeat &
{% endif %}

{% if kibana_running_mode|default("single-process")|lower == "multi-process" %}
NODE_OPTIONS="--max-old-space-size={{ (max_old_space_size / 2) | int }}" ${KIBANA_HOME}/bin/kibana -c /app/config/kibana-ui.yml -c /app/config/kibana.yml $* &
NODE_OPTIONS="--max-old-space-size={{ (max_old_space_size / 2) | int }}" ${KIBANA_HOME}/bin/kibana -c /app/config/kibana-background.yml -c /app/config/kibana.yml $* &
${KIBANA_HOME}/bin/kibana-health-gateway -c /app/config/gateway.yml &
wait -n
{% elif instance_data.instance_capacity > 128 %}
NODE_OPTIONS="--max-old-space-size={{ max_old_space_size }}" ${KIBANA_HOME}/bin/kibana -c /app/config/kibana.yml $*
{% else %}
${KIBANA_HOME}/bin/kibana -c /app/config/kibana.yml $*
{% endif %}
KB_EXIT_CODE=$?
exit $KB_EXIT_CODE
