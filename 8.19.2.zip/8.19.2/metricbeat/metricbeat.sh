#!/bin/sh

# Trace commands for better observability
set -x

{% if metricbeatEnabled is defined && metricbeatEnabled %}

echo "Extracting Metricbeat"

tar xfp /app/metricbeat.tar.gz -C /metricbeat --strip-components=1 --overwrite

echo "Starting Metricbeat"

# Run metricbeat in a loop. If it exits, it will keep trying to run
while true; do
  if [ -f /opt/metricbeat/metricbeat ]; then
    /opt/metricbeat/metricbeat --path.config /app/config/metricbeat --path.data /tmp/metricbeat-data
  else
    /metricbeat/metricbeat --path.config /app/config/metricbeat
  fi
  echo "Metricbeat exited with code $?. Re-running in {{filebeatTimeBetweenRetries}} seconds"
  sleep {{metricbeatTimeBetweenRetries}}
done

{% endif %}
