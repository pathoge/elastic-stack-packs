#!/bin/bash
set -e

# Files created at run-time should be group-writable
umask 0002

function prepend-with-date {
  while read line
  do
    echo $(date +%Y-%m-%dT%H:%M:%S%z) $line
  done
}

{% set instance_data = jsonMap(container.instanceData()) %}

BOOT_LOG_FILE=/app/logs/boot.log
# save stdout and stderr for later
exec 3>&1 4>&2
exec >  >(prepend-with-date | tee -a $BOOT_LOG_FILE)
exec 2> >(prepend-with-date | tee -a $BOOT_LOG_FILE >&2)

echo "Booting at $(date)"

if [[ $(id -u) -eq 0 ]]; then
    echo "ERROR: enterprise_search.sh running as uid 0 (root), exiting."
    exit 1
fi

# A WORKAROUND TO GET GC LOGS IN PLACE
# Ref: https://github.com/elastic/cloud/issues/68802#issuecomment-742567764
export JAVA_GC_LOG_DIR=/app/logs

run_beat () {
  BEAT_NAME=${1}
  # Remove previous running beats  instances to prevent duplicate logging
  pkill ${BEAT_NAME} || true
  # Remove any lockfile left over from a container restart
  rm -f /tmp/${BEAT_NAME}-data/${BEAT_NAME}.lock || true
  while true; do
    /opt/${BEAT_NAME}/${BEAT_NAME} --path.config /app/config/${BEAT_NAME} --path.data /tmp/${BEAT_NAME}-data
    echo "${BEAT_NAME} exited with code $?. Re-running in 2 seconds"
    sleep 2
  done
}

{% if instance_data.observability.logging is defined %}
echo "Starting filebeat"
run_beat filebeat &
{% endif %}
{% if instance_data.observability.metrics is defined %}
echo "Starting metricbeat"
run_beat metricbeat &
{% endif %}

# This allows running with Elasticsearch on 8.0.0-SNAPSHOT version
# Ref: https://github.com/elastic/ent-search/pull/3102
export ALLOW_PREVIEW_ELASTICSEARCH_8X=true
export JAVA_OPTS="-Xms{{ container.heapSize() }}M -Xmx{{ container.heapSize() }}M -XX:OnOutOfMemoryError=/app/on-error-exitcode.sh $ADDITIONAL_JAVA_OPTS"
export FILEBEAT_JAVA_OPTS="-Xmx256M -Xms8M"
export ENT_SEARCH_CONFIG_PATH=/app/config/enterprise_search.yml

{% if heapDumpOnOOM|default(false) %}
if [ -d /app/heap_dumps ]; then
  echo "Enabling heap dump on oom"
  export JAVA_OPTS="$JAVA_OPTS -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/app/heap_dumps"
fi
{% endif %}

{% if enableJemallocMemoryAllocation|default(false) %}
# Use jemalloc as malloc implementation if available
JEMALLOC_LOCATION=`whereis libjemalloc.so.2 | cut -d " " -f 2`
if [[ -z "${JEMALLOC_LOCATION}" ]]; then
  echo "libjemalloc.so.2 has not been found in this Enterprise Search Docker image. Proceeding without loading it."
else
  export LD_PRELOAD=$JEMALLOC_LOCATION
fi
{% endif %}
# Do not abort script if Enterprise Search returns error code
set +e

_term() {
   echo "Caught SIGTERM"
   kill -TERM $(cat /app/es.pid)
}

trap _term TERM

echo "Done preparing, starting Enterprise Search. See service-specific logs for further output."

# restore stdout and stderr
exec 1>&3 2>&4

/usr/share/enterprise-search/bin/enterprise-search all &

ENT_SEARCH_PID=$!
wait ${ENT_SEARCH_PID}
ENT_SEARCH_EXIT_CODE=$?
trap - TERM
wait ${ENT_SEARCH_PID}
# The double wait above is deliberate as the first one returns immediately after TERM signal gets trapped.
# Ref: https://github.com/elastic/cloud-assets/pull/451
if [ "$ENT_SEARCH_EXIT_CODE" -ge "1" ]; then
    echo "Enterprise Search exited with status $ENT_SEARCH_EXIT_CODE, running /app/on-error-exitcode.sh $ENT_SEARCH_EXIT_CODE"
    /app/on-error-exitcode.sh $ENT_SEARCH_EXIT_CODE
fi
exit $ENT_SEARCH_EXIT_CODE
